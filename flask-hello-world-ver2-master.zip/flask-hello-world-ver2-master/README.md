# flask-hello-world-ver2
<p>Please see <a href="https://hidenobu-tokuda.com/how-to-build-a-hello-world-web-application-using-flask-and-deploy-it-to-heroku---more-structured-version/"  target="_blank">this page</a> for more information</p>
